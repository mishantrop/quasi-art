<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '117ef09def0b87d7fdebb05a27759dcf',
      'native_key' => 'quasiform',
      'filename' => 'modNamespace/c7de0d0a2b03592bef33e42b641b35d7.vehicle',
      'namespace' => 'quasiform',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '53b40bcfb4f598b380950aa763999fa6',
      'native_key' => 1,
      'filename' => 'modCategory/9beeb04852ae5d3395a9893a617b860e.vehicle',
      'namespace' => 'quasiform',
    ),
  ),
);