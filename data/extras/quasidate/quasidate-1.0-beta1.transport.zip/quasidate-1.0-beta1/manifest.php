<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7f362b357236f9c5d125bee1c330e060',
      'native_key' => 'quasidate',
      'filename' => 'modNamespace/e0c678ac85dd0c77b3a25a345d345f4d.vehicle',
      'namespace' => 'quasidate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '6bd5ce37f88e243ec7ef1fe301790e25',
      'native_key' => 1,
      'filename' => 'modCategory/6e00ee829aa8b1c56b9ff197302d345c.vehicle',
      'namespace' => 'quasidate',
    ),
  ),
);