<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '984afd26649850632a80f4a1c53978a9',
      'native_key' => 'quasinotfound',
      'filename' => 'modNamespace/a3121bc5a0bc2b4686bb1f2917cffaf1.vehicle',
      'namespace' => 'quasinotfound',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bdbca346a574d6f4f24e06bcd5d1599d',
      'native_key' => 11,
      'filename' => 'modPlugin/217672bec3f4f1d5bee046815f3fa309.vehicle',
      'namespace' => 'quasinotfound',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '66538f110833b804ec71d869d49314d9',
      'native_key' => 1,
      'filename' => 'modCategory/80872cff307590e42699e864b7775c1c.vehicle',
      'namespace' => 'quasinotfound',
    ),
  ),
);