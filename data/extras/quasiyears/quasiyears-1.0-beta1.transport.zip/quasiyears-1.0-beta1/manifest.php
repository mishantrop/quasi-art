<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '16df3e84c28fae4468f99c74efa440fe',
      'native_key' => 'quasiyears',
      'filename' => 'modNamespace/1e6cbb49a71004b87f6d80b45f637e54.vehicle',
      'namespace' => 'quasiyears',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2322911f6a0b99a1075876946267251d',
      'native_key' => 1,
      'filename' => 'modCategory/dccaa2694e97e0b5327e190600461ea6.vehicle',
      'namespace' => 'quasiyears',
    ),
  ),
);